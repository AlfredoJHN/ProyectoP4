﻿namespace servidor_bingo
{
    partial class Servidor
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnComenzar = new System.Windows.Forms.Button();
            this.tbJugadores = new System.Windows.Forms.TextBox();
            this.Jugadores = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbModo = new System.Windows.Forms.TextBox();
            this.lblInfo = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnComenzar
            // 
            this.btnComenzar.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnComenzar.ForeColor = System.Drawing.SystemColors.Window;
            this.btnComenzar.Location = new System.Drawing.Point(468, 281);
            this.btnComenzar.Name = "btnComenzar";
            this.btnComenzar.Size = new System.Drawing.Size(94, 32);
            this.btnComenzar.TabIndex = 0;
            this.btnComenzar.Text = "Comenzar";
            this.btnComenzar.UseVisualStyleBackColor = false;
            this.btnComenzar.Click += new System.EventHandler(this.btnComenzar_Click);
            // 
            // tbJugadores
            // 
            this.tbJugadores.Location = new System.Drawing.Point(213, 138);
            this.tbJugadores.Name = "tbJugadores";
            this.tbJugadores.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.tbJugadores.Size = new System.Drawing.Size(130, 22);
            this.tbJugadores.TabIndex = 2;
            // 
            // Jugadores
            // 
            this.Jugadores.AutoSize = true;
            this.Jugadores.Location = new System.Drawing.Point(40, 143);
            this.Jugadores.Name = "Jugadores";
            this.Jugadores.Size = new System.Drawing.Size(151, 17);
            this.Jugadores.TabIndex = 3;
            this.Jugadores.Text = "Cantidad de jugadores";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Modo de juego";
            // 
            // tbModo
            // 
            this.tbModo.Location = new System.Drawing.Point(213, 232);
            this.tbModo.Name = "tbModo";
            this.tbModo.Size = new System.Drawing.Size(130, 22);
            this.tbModo.TabIndex = 6;
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.BackColor = System.Drawing.SystemColors.Window;
            this.lblInfo.Location = new System.Drawing.Point(115, 307);
            this.lblInfo.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(0, 17);
            this.lblInfo.TabIndex = 7;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Items.AddRange(new object[] {
            "1. Fila horizontal",
            "2. Fila vertical",
            "3. Forma de T",
            "4. Diagonal",
            "5. Diagonal inversa",
            "6. Cartón lleno",
            "7. Cuatro esquinas"});
            this.listBox1.Location = new System.Drawing.Point(431, 115);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(131, 116);
            this.listBox1.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(392, 31);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 29);
            this.label10.TabIndex = 103;
            this.label10.Text = "O";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(331, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 29);
            this.label9.TabIndex = 102;
            this.label9.Text = "G";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(271, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 29);
            this.label8.TabIndex = 101;
            this.label8.Text = "N";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(208, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(19, 29);
            this.label7.TabIndex = 100;
            this.label7.Text = "I";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(143, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 29);
            this.label3.TabIndex = 99;
            this.label3.Text = "B";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(431, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 17);
            this.label2.TabIndex = 104;
            this.label2.Text = "Modos de juego";
            // 
            // Servidor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(574, 323);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.tbModo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Jugadores);
            this.Controls.Add(this.tbJugadores);
            this.Controls.Add(this.btnComenzar);
            this.Name = "Servidor";
            this.Text = "Servidor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        private System.Windows.Forms.Button btnComenzar;
        private System.Windows.Forms.TextBox tbJugadores;
        private System.Windows.Forms.Label Jugadores;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbModo;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}