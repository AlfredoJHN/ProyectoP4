﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Collections;

namespace servidor_bingo
{
    public partial class Servidor : Form
    {

        public static Hashtable lista_clientes = new Hashtable();
        public static int gan = new int();

        public Servidor()
        {
            InitializeComponent();

        }

        private void btnComenzar_Click(object sender, EventArgs e)
        {

            int jugadores, tipo;
            jugadores = int.Parse(tbJugadores.Text);
            tipo = int.Parse(tbModo.Text);
            MessageBox.Show("Se ha iniciado el servidor de bingo con " + jugadores + " jugadores");

            System.Net.IPAddress ip = System.Net.IPAddress.Parse("127.0.0.1");
            TcpListener serverSocket = new TcpListener(ip, 8888);

            TcpClient clientSocket = default(TcpClient);

            int contador = 0;

            IPAddress[] aryLocalAddr = null;
            String localhost = "";
            localhost = Dns.GetHostName();
            //IPHostEntry ipEntry = Dns.GetHostByName(localhost);
            IPHostEntry ipEntry = Dns.GetHostEntry(localhost);
            aryLocalAddr = ipEntry.AddressList;

            serverSocket.Start();


            contador = 0;

            try
            {
                bool empieza = true;
                while (empieza == true)
                {
                    string nombre;
                    contador += 1;
                    string datos_cliente = null;
                    try
                    {
                        clientSocket = serverSocket.AcceptTcpClient();
                        byte[] bytesFrom = new byte[1024];

                        NetworkStream networkStream = clientSocket.GetStream();
                        networkStream.Read(bytesFrom, 0, 1024);
                        //networkStream.Read(bytesFrom, 0, (int)clientSocket.ReceiveBufferSize);
                        datos_cliente = System.Text.Encoding.ASCII.GetString(bytesFrom);
                        datos_cliente = datos_cliente.Substring(0, datos_cliente.IndexOf("$"));
                    }
                    catch (Exception)
                    {
                        //Console.WriteLine();
                        // Console.WriteLine();
                    }

                    lista_clientes.Add(datos_cliente, clientSocket);
                    //  Console.WriteLine("");
                    //  Console.WriteLine("");
                    //  Console.WriteLine(datos_cliente + " Se ha conectado");
                    //Console.ReadKey();

                    handleClinet client = new handleClinet();

                    client.startClient(clientSocket, datos_cliente, lista_clientes);
                    nombre = datos_cliente;

                    intercambio_datos(datos_cliente + " se ha unido", datos_cliente, false);

                    if (lista_clientes.Count == jugadores)
                    {

                        serverSocket.Stop();
                        if (tipo == 1) { intercambio_datos("H1", datos_cliente, false); }
                        if (tipo == 2) { intercambio_datos("H2", datos_cliente, false); }
                        if (tipo == 3) { intercambio_datos("T1", datos_cliente, false); }
                        if (tipo == 4) { intercambio_datos("D1", datos_cliente, false); }
                        if (tipo == 5) { intercambio_datos("D2", datos_cliente, false); }
                        if (tipo == 6) { intercambio_datos("Bi", datos_cliente, false); }
                        if (tipo == 7) { intercambio_datos("E1", datos_cliente, false); }

                        intercambio_datos("", datos_cliente, false);
                        System.Threading.Thread.Sleep(10000);
                        intercambio_datos("", datos_cliente, false);
                        intercambio_datos("Comienza el Juego", datos_cliente, false);
                        intercambio_datos("", datos_cliente, false);

                        juego();
                        intercambio_datos("El juego ha finalizado, gracias por participar ", datos_cliente, false);
                        intercambio_datos("0", datos_cliente, false);
                        empieza = false;

                    }
                }
            }
            catch (Exception)
            {
                //  Console.WriteLine("No hay usuarios conectados");
                // Console.WriteLine();
                //   Console.WriteLine();
                System.Threading.Thread.Sleep(10000);
                clientSocket.Close();
                serverSocket.Stop();

            }
        }
        public static void intercambio_datos(string msg, string uName, bool flag)
        {
            try
            {
                foreach (DictionaryEntry Item in lista_clientes)
                {
                    TcpClient broadcastSocket;
                    broadcastSocket = (TcpClient)Item.Value;
                    NetworkStream broadcastStream = broadcastSocket.GetStream();
                    Byte[] broadcastBytes = null;

                    if (flag == true)
                    {

                        if (msg == "BINGO")
                        {
                            gan = 1;
                            broadcastBytes = Encoding.ASCII.GetBytes(msg + "El ganador es  " + uName);

                        }
                        else
                        {
                        }
                    }

                    else
                    {

                        broadcastBytes = Encoding.ASCII.GetBytes(msg);

                    }

                    broadcastStream.Write(broadcastBytes, 0, broadcastBytes.Length);

                    broadcastStream.Flush();

                }
            }
            catch { }
        }

        public static void juego()
        {
            try
            {
                int[] num = new int[75];
                Random r = new Random();
                int i = new int();
                int j = new int();
                int auxiliar = 0;
                int contador = 0;
                /// GENERA 
                for (i = 0; i < 74; i++)
                {
                    auxiliar = r.Next(1, 75);
                    bool continuar = false;

                    while (!continuar)
                    {
                        for (j = 0; j <= contador; j++)
                        {
                            if (auxiliar == num[j])
                            {
                                continuar = true;
                                j = contador;
                            }
                        }
                        if (continuar)
                        {
                            auxiliar = r.Next(1, 75);
                            continuar = false;
                        }
                        else
                        {
                            continuar = true;
                            num[contador] = auxiliar;
                            contador++;
                        }
                    }
                }

                for (i = 0; i < 75; i++)
                {

                    System.Threading.Thread.Sleep(10000);
                    foreach (DictionaryEntry Item in lista_clientes)
                    {

                        TcpClient broadcastSocket;

                        broadcastSocket = (TcpClient)Item.Value;

                        NetworkStream envio = broadcastSocket.GetStream();

                        Byte[] broadcastBytes = null;
                        broadcastBytes = Encoding.ASCII.GetBytes(Convert.ToString(num[i]));
                        envio.Write(broadcastBytes, 0, broadcastBytes.Length);
                        envio.Flush();

                        if (gan == 1)
                        {
                            i = 74;

                            break;
                        }

                    }
                }
            }
            catch { }

        }
    }

    public class handleClinet
    {

        TcpClient clientSocket;
        string clNo;
        Hashtable lista_clientes;

        public void startClient(TcpClient inClientSocket, string clineNo, Hashtable cLista)
        {
            this.clientSocket = inClientSocket;
            this.clNo = clineNo;
            this.lista_clientes = cLista;
            Thread ctThread = new Thread(para_chat);
            ctThread.Start();
        }

        private void para_chat()
        {

            int requestCount = 0;
            byte[] bytesFrom = new byte[1024];
            string datos_cliente = null;
            string rCount = null;
            requestCount = 0;

            try
            {
                while ((true))
                {
                    requestCount = requestCount + 1;
                    NetworkStream networkStream = clientSocket.GetStream();
                    networkStream.Read(bytesFrom, 0, 1024);
                    datos_cliente = System.Text.Encoding.ASCII.GetString(bytesFrom);
                    datos_cliente = datos_cliente.Substring(0, datos_cliente.IndexOf("$"));
                    rCount = Convert.ToString(requestCount);
                    Servidor.intercambio_datos(datos_cliente, clNo, true);
                }
            }
            catch
            {
                lista_clientes.Remove(clNo);
                if (lista_clientes.Count == 1)
                {
                }
                if (lista_clientes.Count == 0)
                {
                    //Console.WriteLine("No hay usuarios conectados");
                    clientSocket.Close();
                    Environment.Exit(0);

                }
            }
        }
    }
}

